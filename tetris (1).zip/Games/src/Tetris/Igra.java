package Tetris;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Igra extends JFrame{

    private JLabel status;

    public Igra() {

        status = new JLabel("0");
        add(status, BorderLayout.SOUTH);

        Okvir panela=new Okvir(this);
        add(panela);
        panela.novKos();
        panela.repaint();

       setTitle("Tetris");
       setSize(300, 400);
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
    }

    JLabel getStatusBar() {

        return status;
    }

    public static void main(String[] args) {
    	
    	Igra tetris=new Igra();
    	tetris.setLocationRelativeTo(null);
    	tetris.setVisible(true);
    	
       
    }
}