package Tetris;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Random;

import Tetris.Oblika.Tetrominoe;

public class Oblika {
	protected enum Tetrominoe {
        NiOblika, ZOblika, SOblika, �rtaOblika,
        TOblika, KvadratnaOblika, LOblika, NarobeLOblika
    }

    private Tetrominoe kosOblika;
    private int[][] koordinate;

    public Oblika() {

        koordinate = new int[4][2];
        narediObliko(Tetrominoe.NiOblika);
    }

    void narediObliko(Tetrominoe oblika) {

        int[][][] koordinateTabela = new int[][][]{
                {{0, 0}, {0, 0}, {0, 0}, {0, 0}},
                {{0, -1}, {0, 0}, {-1, 0}, {-1, 1}},
                {{0, -1}, {0, 0}, {1, 0}, {1, 1}},
                {{0, -1}, {0, 0}, {0, 1}, {0, 2}},
                {{-1, 0}, {0, 0}, {1, 0}, {0, 1}},
                {{0, 0}, {1, 0}, {0, 1}, {1, 1}},
                {{-1, -1}, {0, -1}, {0, 0}, {0, 1}},
                {{1, -1}, {0, -1}, {0, 0}, {0, 1}}
        };

        for (int i = 0; i < 4; i++) {

            System.arraycopy(koordinateTabela[oblika.ordinal()], 0, koordinate, 0, 4);
        }

        kosOblika = oblika;
    }

    private void setX(int index, int x) {

        koordinate[index][0] = x;
    }

    private void setY(int index, int y) {

        koordinate[index][1] = y;
    }

    int x(int index) {

        return koordinate[index][0];
    }

    int y(int index) {

        return koordinate[index][1];
    }

    Tetrominoe dobiObliko() {

        return kosOblika;
    }

    void setRandomShape() {

        var r = new Random();
        int x = Math.abs(r.nextInt()) % 7 + 1;

        Tetrominoe[] vrednost = Tetrominoe.values();
        narediObliko(vrednost[x]);
    }

    public int minX() {

        int m = koordinate[0][0];

        for (int i = 0; i < 4; i++) {

            m = Math.min(m, koordinate[i][0]);
        }

        return m;
    }


    int minY() {

        int m = koordinate[0][1];

        for (int i = 0; i < 4; i++) {

            m = Math.min(m, koordinate[i][1]);
        }

        return m;
    }

    Oblika obrniLevo() {

        if (kosOblika == Tetrominoe.KvadratnaOblika) {

            return this;
        }

        var rezultat = new Oblika();
        rezultat.kosOblika = kosOblika;

        for (int i = 0; i < 4; i++) {

            rezultat.setX(i, y(i));
            rezultat.setY(i, -x(i));
        }

        return rezultat;
    }

    Oblika obrniDesno() {

        if (kosOblika == Tetrominoe.KvadratnaOblika) {

            return this;
        }

        var rezultat = new Oblika();
        rezultat.kosOblika = kosOblika;

        for (int i = 0; i < 4; i++) {

        	rezultat.setX(i, -y(i));
        	rezultat.setY(i, x(i));
        }

        return rezultat;
    }
    
    
    
    
}
