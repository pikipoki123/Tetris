package Tetris;
import Tetris.Oblika.Tetrominoe;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.plaf.DimensionUIResource;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Okvir extends JPanel implements ActionListener{
	
	 final int sirinaOkvir = 10;
     final int visinaOkvir = 22;
     final int interval = 300;

     Timer timer;
     boolean kon�ano_padanje = false;
     boolean zaustavljeno = false;
     boolean zaceto = false;
     int stLinijZbrisanih = 0;
     int trenutenX = 0;
     int trenutenY = 0;
     JLabel status;
     Oblika trenutenKos;
     Tetrominoe[] okvir;

    
    
    public Okvir(Igra parent) {
    	setFocusable(true);
    	trenutenKos=new Oblika();
    	timer =new Timer(400, this);
        
        status=parent.getStatusBar();
        okvir =new Tetrominoe[sirinaOkvir*visinaOkvir];
        pocistiOkvir();
    

        addKeyListener((KeyListener) new TAdapter(parent));
    }

    private int kvadratSirina() {

        return (int) getSize().getWidth() / sirinaOkvir;
    }

    private int kvadratVisina() {

        return (int) getSize().getHeight() / visinaOkvir;
    }

    private Tetrominoe oblikaNa(int x, int y) {

        return okvir[(y *  sirinaOkvir) + x];
    }

    public void start() {

    	if (zaustavljeno)
    		return;
    	
    	zaceto=true;
    	kon�ano_padanje=false;
    	stLinijZbrisanih=0;
    	pocistiOkvir();
    	novKos();
    	
    	trenutenKos = new Oblika();
        okvir = new Tetrominoe[sirinaOkvir * visinaOkvir];

        timer = new Timer(interval, new KrogIgre());
        timer.start();
    }

    protected void ustavi() {

    	if(!zaceto)
    		return;
    	
    	zaustavljeno = !zaustavljeno;

        if (zaustavljeno) {

            status.setText("zavstavljeno");
        } else {

            status.setText(String.valueOf(stLinijZbrisanih));
        }

        repaint();
    }

    

    public void paint(Graphics g) {

    	super.paint(g);
    	
        Dimension velikost = getSize();
        int zgornjiRob = (int) velikost.getHeight() - visinaOkvir * kvadratVisina();

        for (int i = 0; i < visinaOkvir; i++) {

            for (int j = 0; j < sirinaOkvir; j++) {

                Tetrominoe oblika = oblikaNa(j, visinaOkvir - i - 1);

                if (oblika != Tetrominoe.NiOblika) {

                	 narisiKvadrat(g, j * kvadratSirina(), zgornjiRob + i * kvadratVisina(), oblika);
                }
            }
        }

        if (trenutenKos.dobiObliko() != Tetrominoe.NiOblika) {

            for (int i = 0; i < 4; i++) {

                int x = trenutenX + trenutenKos.x(i);
                int y = trenutenY - trenutenKos.y(i);

                narisiKvadrat(g, x * kvadratSirina(),
                        zgornjiRob + (visinaOkvir - y - 1) * kvadratVisina(),
                        trenutenKos.dobiObliko());
            }
        }
    }

   

	protected void dropDown() {

        int novY = trenutenY;

        while (novY > 0) {

            if (!tryMove(trenutenKos, trenutenX, novY - 1)) {

                break;
            }

            novY--;
        }

        PadelKos();
    }

    protected void oneLineDown() {

        if (!tryMove(trenutenKos, trenutenX, trenutenY - 1)) {

            PadelKos();
        }
    }

    private void pocistiOkvir() {

        for (int i = 0; i < visinaOkvir * sirinaOkvir; i++) {

            okvir[i] = Tetrominoe.NiOblika;
        }
    }

    private void PadelKos() {

        for (int i = 0; i < 4; i++) {

            int x = trenutenX + trenutenKos.x(i);
            int y = trenutenY - trenutenKos.y(i);
            okvir[(y * sirinaOkvir) + x] = trenutenKos.dobiObliko();
        }

        removeFullLines();

        if (!kon�ano_padanje) {

            novKos();
        }
    }

    protected void novKos() {

    	trenutenKos.setRandomShape();
        trenutenX = sirinaOkvir / 2 + 1;
        trenutenY = visinaOkvir - 1 + trenutenKos.minY();

        if (!tryMove(trenutenKos, trenutenX, trenutenY)) {

        	trenutenKos.narediObliko(Tetrominoe.NiOblika);
            timer.stop();

            var msg = String.format("Igra je kon�ana. Rezultat: %d", stLinijZbrisanih);
            status.setText(msg);
        }
    }

    protected boolean tryMove(Oblika novKos, int newX, int newY) {

        for (int i = 0; i < 4; i++) {

            int x = newX + novKos.x(i);
            int y = newY - novKos.y(i);

            if (x < 0 || x >= sirinaOkvir || y < 0 || y >= visinaOkvir) {

                return false;
            }

            if (oblikaNa(x, y) != Tetrominoe.NiOblika) {

                return false;
            }
        }

        trenutenKos = novKos;
        trenutenX = newX;
        trenutenY = newY;

        repaint();

        return true;
    }

    private void removeFullLines() {

        int numFullLines = 0;

        for (int i = visinaOkvir - 1; i >= 0; i--) {

            boolean lineIsFull = true;

            for (int j = 0; j < sirinaOkvir; j++) {

                if (oblikaNa(j, i) == Tetrominoe.NiOblika) {

                    lineIsFull = false;
                    break;
                }
            }

            if (lineIsFull) {

                numFullLines++;

                for (int k = i; k < visinaOkvir - 1; k++) {
                    for (int j = 0; j < sirinaOkvir; j++) {
                        okvir[(k * sirinaOkvir) + j] = oblikaNa(j, k + 1);
                    }
                }
            }
        }

        if (numFullLines > 0) {

        	stLinijZbrisanih += numFullLines;

            status.setText(String.valueOf(stLinijZbrisanih));
            kon�ano_padanje = true;
            trenutenKos.narediObliko(Tetrominoe.NiOblika);
        }
    }

    private void narisiKvadrat(Graphics g, int x, int y, Tetrominoe shape) {
    	
    	super.paint(g);

        Color barve[] = {new Color(0, 0, 0), new Color(204, 102, 102),
                new Color(102, 204, 102), new Color(102, 102, 204),
                new Color(204, 204, 102), new Color(204, 102, 204),
                new Color(102, 204, 204), new Color(218, 170, 0)
        };

        var barva = barve[shape.ordinal()];

        g.setColor(barva);
        g.fillRect(x + 1, y + 1, kvadratSirina() - 2, kvadratVisina() - 2);

        g.setColor(barva.brighter());
        g.drawLine(x, y + kvadratVisina() - 1, x, y);
        g.drawLine(x, y, x + kvadratSirina() - 1, y);

        g.setColor(barva.darker());
        g.drawLine(x + 1, y + kvadratVisina() - 1,
                x + kvadratSirina() - 1, y + kvadratVisina() - 1);
        g.drawLine(x + kvadratSirina() - 1, y + kvadratVisina() - 1,
                x + kvadratSirina() - 1, y + 1);
    }

    class KrogIgre implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            doGameCycle();
        }
    }

    private void doGameCycle() {

        posodobi();
        repaint();
    }

    private void posodobi() {

        if (zaustavljeno) {

            return;
        }

        if (kon�ano_padanje) {

        	kon�ano_padanje = false;
            novKos();
        } else {

            oneLineDown();
        }
    }

	public void keyPressed(KeyEvent e) {
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(kon�ano_padanje) {
			kon�ano_padanje=false;
			novKos();
		}else
			oneLineDown();
		
	}
	
	class TAdapter extends KeyAdapter {

        public TAdapter(Igra parent) {
    		super();
    		
    	}

    	@Override
        public void keyPressed(KeyEvent e) {

            if (trenutenKos.dobiObliko() == Tetrominoe.NiOblika) {

                return;
            }

            int keycode = e.getKeyCode();

            // Java 12 switch expressions
            switch (keycode) {

                case KeyEvent.VK_P:ustavi();break;
                case KeyEvent.VK_LEFT : tryMove(trenutenKos, trenutenX - 1, trenutenY);break;
                case KeyEvent.VK_RIGHT :tryMove(trenutenKos, trenutenX + 1, trenutenY);break;
                case KeyEvent.VK_DOWN : tryMove(trenutenKos.obrniDesno(), trenutenX, trenutenY);break;
                case KeyEvent.VK_UP :tryMove(trenutenKos.obrniLevo(), trenutenX, trenutenY);break;
                case KeyEvent.VK_SPACE: dropDown();break;
                case KeyEvent.VK_D : oneLineDown();break;
            }
        }
	}
	
}
    

    
