package Tetris;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import Tetris.Oblika.Tetrominoe;



class TAdapter extends Okvir {

    public TAdapter(Igra parent) {
		super(parent);
		
	}

	@Override
    public void keyPressed(KeyEvent e) {

        if (trenutenKos.dobiObliko() == Tetrominoe.NiOblika) {

            return;
        }

        int keycode = e.getKeyCode();

        // Java 12 switch expressions
        switch (keycode) {

            case KeyEvent.VK_P -> ustavi();
            case KeyEvent.VK_LEFT -> tryMove(trenutenKos, trenutenX - 1, trenutenY);
            case KeyEvent.VK_RIGHT -> tryMove(trenutenKos, trenutenX + 1, trenutenY);
            case KeyEvent.VK_DOWN -> tryMove(trenutenKos.obrniDesno(), trenutenX, trenutenY);
            case KeyEvent.VK_UP -> tryMove(trenutenKos.obrniLevo(), trenutenX, trenutenY);
            case KeyEvent.VK_SPACE -> dropDown();
            case KeyEvent.VK_D -> oneLineDown();
        }
    }
}
