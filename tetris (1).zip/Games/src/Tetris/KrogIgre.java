package Tetris;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class KrogIgre extends Okvir implements ActionListener  {

	public KrogIgre(Igra parent) {
		super(parent);
	}


	@Override
    public void actionPerformed(ActionEvent e) {

        doGameCycle();
    }


private void doGameCycle() {

    update();
    repaint();
}




private void update() {

    if (zaustavljeno) {

        return;
    }

    if (kon�ano_padanje) {

    	kon�ano_padanje = false;
        novKos();
    } else {

        oneLineDown();
    }
}
}
