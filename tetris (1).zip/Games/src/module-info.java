module Games {
	requires java.desktop;
}