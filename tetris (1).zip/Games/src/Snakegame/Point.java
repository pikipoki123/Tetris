package Snakegame;

public class Point {

}
