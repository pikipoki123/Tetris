package Snakegame;

public class Game {

}
