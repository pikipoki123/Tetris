package Snakegame;

public class Kaca {

}
