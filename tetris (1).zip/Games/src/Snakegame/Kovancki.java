package Snakegame;

public class Kovancki {

}
